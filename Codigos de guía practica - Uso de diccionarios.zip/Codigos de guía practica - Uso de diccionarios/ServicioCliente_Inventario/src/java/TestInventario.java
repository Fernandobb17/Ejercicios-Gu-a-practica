import sw.InventarioSW;
import sw.InventarioSW_Service;
public class TestInventario {
    public static void main(String[] args) {

        InventarioSW_Service service = new InventarioSW_Service();
        InventarioSW ws = service.getInventarioSWPort();

        // ── PRUEBA 1: Buscar producto por ID ──────────────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 1: BUSCAR PRODUCTO POR ID = 3");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.buscarProductoPorId(3));

        // ── PRUEBA 2: ID que no existe ────────────────────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 2: BUSCAR PRODUCTO ID INEXISTENTE");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.buscarProductoPorId(99));

        // ── PRUEBA 3: Listar productos por categoría ──────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 3: PRODUCTOS POR CATEGORÍA = Electrónica");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.listarProductosPorCategoria("Electrónica"));

        // ── PRUEBA 4: Categoría inexistente ───────────────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 4: CATEGORÍA INEXISTENTE");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.listarProductosPorCategoria("Deportes"));

        // ── PRUEBA 5: Listar productos por proveedor ──────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 5: PRODUCTOS POR PROVEEDOR RUC = 0987654321001");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.listarProductosPorProveedor("0987654321001"));

        // ── PRUEBA 6: Agregar nuevo producto ──────────────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 6: AGREGAR PRODUCTO NUEVO");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.agregarProducto("Teclado Mecánico", 65.00, 40, 1, 1));

        // ── PRUEBA 7: Verificar que el producto nuevo aparece ─────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 7: CATEGORÍA Electrónica DESPUÉS DE AGREGAR");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.listarProductosPorCategoria("Electrónica"));

        // ── PRUEBA 8: Resumen de inventario ───────────────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 8: RESUMEN DE INVENTARIO");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.resumenInventario());

        // ── PRUEBA 9: Listar todos los mapas ──────────────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 9: LISTAR TODOS LOS MAPAS");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.listarTodosLosMapas());
    }
}