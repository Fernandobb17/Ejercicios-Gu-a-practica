package sw;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import java.util.*;
import modelo.*;

@WebService(serviceName = "InventarioSW")
public class InventarioSW {

    private static Map<Integer, Categoria> mapCategorias  = new HashMap<>();
    private static Map<Integer, Proveedor> mapProveedores = new HashMap<>();
    private static Map<Integer, Producto>  mapProductos   = new LinkedHashMap<>();

    private static Map<String, Integer>        idxCategoriaNombre       = new HashMap<>();
    private static Map<String, Integer>        idxProveedorRuc          = new HashMap<>();
    private static Map<Integer, List<Integer>> idxProductosPorCategoria = new HashMap<>();
    private static Map<Integer, List<Integer>> idxProductosPorProveedor = new HashMap<>();

    static {
        // ── Categorías ────────────────────────────────────────────────────
        Categoria cat1 = new Categoria(1, "Electrónica",  "Dispositivos y componentes electrónicos");
        Categoria cat2 = new Categoria(2, "Alimentos",    "Productos alimenticios y bebidas");
        Categoria cat3 = new Categoria(3, "Herramientas", "Herramientas manuales y eléctricas");

        mapCategorias.put(cat1.getIdCategoria(), cat1);
        mapCategorias.put(cat2.getIdCategoria(), cat2);
        mapCategorias.put(cat3.getIdCategoria(), cat3);

        idxCategoriaNombre.put(cat1.getNombre().toLowerCase(), cat1.getIdCategoria());
        idxCategoriaNombre.put(cat2.getNombre().toLowerCase(), cat2.getIdCategoria());
        idxCategoriaNombre.put(cat3.getNombre().toLowerCase(), cat3.getIdCategoria());

        // ── Proveedores ───────────────────────────────────────────────────
        Proveedor prov1 = new Proveedor(1, "1234567890001", "TechSupply S.A.",   "0991234567", "tech@gmail.com",   "Ecuador");
        Proveedor prov2 = new Proveedor(2, "0987654321001", "AlimEx Cía. Ltda.", "0997654321", "alimex@gmail.com", "Colombia");
        Proveedor prov3 = new Proveedor(3, "1122334455001", "HerraMax S.A.",     "0993344556", "herra@gmail.com",  "Perú");

        mapProveedores.put(prov1.getIdProveedor(), prov1);
        mapProveedores.put(prov2.getIdProveedor(), prov2);
        mapProveedores.put(prov3.getIdProveedor(), prov3);

        idxProveedorRuc.put(prov1.getRuc(), prov1.getIdProveedor());
        idxProveedorRuc.put(prov2.getRuc(), prov2.getIdProveedor());
        idxProveedorRuc.put(prov3.getRuc(), prov3.getIdProveedor());

        // ── Productos ─────────────────────────────────────────────────────
        Producto p1 = new Producto(1, "Laptop Lenovo",     950.00,  15, cat1, prov1);
        Producto p2 = new Producto(2, "Mouse Inalámbrico",  25.00,  80, cat1, prov1);
        Producto p3 = new Producto(3, "Arroz 25kg",         18.50, 200, cat2, prov2);
        Producto p4 = new Producto(4, "Aceite 1L",           3.20, 500, cat2, prov2);
        Producto p5 = new Producto(5, "Taladro Bosch",      120.00,  30, cat3, prov3);
        Producto p6 = new Producto(6, "Juego de Llaves",     45.00,  60, cat3, prov3);

        mapProductos.put(p1.getIdProducto(), p1);
        mapProductos.put(p2.getIdProducto(), p2);
        mapProductos.put(p3.getIdProducto(), p3);
        mapProductos.put(p4.getIdProducto(), p4);
        mapProductos.put(p5.getIdProducto(), p5);
        mapProductos.put(p6.getIdProducto(), p6);

        // ── Relaciones bidireccionales Categoria → Productos ──────────────
        cat1.setProductos(Arrays.asList(p1, p2));
        cat2.setProductos(Arrays.asList(p3, p4));
        cat3.setProductos(Arrays.asList(p5, p6));

        // ── Relaciones bidireccionales Proveedor → Productos ──────────────
        prov1.setProductos(Arrays.asList(p1, p2));
        prov2.setProductos(Arrays.asList(p3, p4));
        prov3.setProductos(Arrays.asList(p5, p6));

        // ── Índices agrupados ─────────────────────────────────────────────
        idxProductosPorCategoria.put(1, Arrays.asList(1, 2));
        idxProductosPorCategoria.put(2, Arrays.asList(3, 4));
        idxProductosPorCategoria.put(3, Arrays.asList(5, 6));

        idxProductosPorProveedor.put(1, Arrays.asList(1, 2));
        idxProductosPorProveedor.put(2, Arrays.asList(3, 4));
        idxProductosPorProveedor.put(3, Arrays.asList(5, 6));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MÉTODO 1 — buscarProductoPorId
    // ═══════════════════════════════════════════════════════════════════════
    @WebMethod(operationName = "buscarProductoPorId")
    public String buscarProductoPorId(@WebParam(name = "idProducto") int idProducto) {

        Producto p = mapProductos.get(idProducto);

        if (p == null) {
            return "ERROR: No existe un producto con ID: " + idProducto;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("=== PRODUCTO ENCONTRADO ===\n");
        sb.append("ID        : ").append(p.getIdProducto()).append("\n");
        sb.append("Nombre    : ").append(p.getNombre()).append("\n");
        sb.append("Precio    : $").append(p.getPrecio()).append("\n");
        sb.append("Stock     : ").append(p.getStock()).append(" unidades\n");
        sb.append("Categoría : ").append(p.getCategoria().getNombre()).append("\n");
        sb.append("Proveedor : ").append(p.getProveedor().getNombre()).append("\n");
        return sb.toString();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MÉTODO 2 — listarProductosPorCategoria
    //   Ahora navega directamente por cat.getProductos() en lugar de
    //   solo usar el índice, aprovechando la relación bidireccional
    // ═══════════════════════════════════════════════════════════════════════
    @WebMethod(operationName = "listarProductosPorCategoria")
    public String listarProductosPorCategoria(
            @WebParam(name = "nombreCategoria") String nombreCategoria) {

        Integer idCat = idxCategoriaNombre.get(nombreCategoria.toLowerCase());
        if (idCat == null) {
            return "ERROR: No existe la categoría '" + nombreCategoria + "'.";
        }

        Categoria cat = mapCategorias.get(idCat);

        // Navegar directo por la relación bidireccional
        List<Producto> productos = cat.getProductos();
        if (productos == null || productos.isEmpty()) {
            return "La categoría '" + nombreCategoria + "' no tiene productos registrados.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("=== PRODUCTOS DE CATEGORÍA: ").append(cat.getNombre().toUpperCase()).append(" ===\n");
        sb.append("Descripción : ").append(cat.getDescripcion()).append("\n\n");

        for (Producto p : productos) {
            sb.append("  ID        : ").append(p.getIdProducto()).append("\n");
            sb.append("  Nombre    : ").append(p.getNombre()).append("\n");
            sb.append("  Precio    : $").append(p.getPrecio()).append("\n");
            sb.append("  Stock     : ").append(p.getStock()).append(" unidades\n");
            sb.append("  Proveedor : ").append(p.getProveedor().getNombre()).append("\n");
            sb.append("  ─────────────────────────\n");
        }
        return sb.toString();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MÉTODO 3 — listarProductosPorProveedor
    //   Igual que el método 2, ahora navega por prov.getProductos()
    // ═══════════════════════════════════════════════════════════════════════
    @WebMethod(operationName = "listarProductosPorProveedor")
    public String listarProductosPorProveedor(
            @WebParam(name = "rucProveedor") String rucProveedor) {

        Integer idProv = idxProveedorRuc.get(rucProveedor);
        if (idProv == null) {
            return "ERROR: No existe un proveedor con RUC: " + rucProveedor;
        }

        Proveedor prov = mapProveedores.get(idProv);

        // Navegar directo por la relación bidireccional
        List<Producto> productos = prov.getProductos();
        if (productos == null || productos.isEmpty()) {
            return "El proveedor '" + prov.getNombre() + "' no tiene productos registrados.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("=== PRODUCTOS DE PROVEEDOR: ").append(prov.getNombre().toUpperCase()).append(" ===\n");
        sb.append("RUC  : ").append(prov.getRuc()).append("\n");
        sb.append("País : ").append(prov.getPais()).append("\n\n");

        for (Producto p : productos) {
            sb.append("  ID        : ").append(p.getIdProducto()).append("\n");
            sb.append("  Nombre    : ").append(p.getNombre()).append("\n");
            sb.append("  Precio    : $").append(p.getPrecio()).append("\n");
            sb.append("  Stock     : ").append(p.getStock()).append(" unidades\n");
            sb.append("  Categoría : ").append(p.getCategoria().getNombre()).append("\n");
            sb.append("  ─────────────────────────\n");
        }
        return sb.toString();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MÉTODO 4 — agregarProducto
    // ═══════════════════════════════════════════════════════════════════════
    @WebMethod(operationName = "agregarProducto")
    public String agregarProducto(
            @WebParam(name = "nombre")      String nombre,
            @WebParam(name = "precio")      double precio,
            @WebParam(name = "stock")       int    stock,
            @WebParam(name = "idCategoria") int    idCategoria,
            @WebParam(name = "idProveedor") int    idProveedor) {

        Categoria cat = mapCategorias.get(idCategoria);
        if (cat == null) {
            return "ERROR: No existe una categoría con ID: " + idCategoria;
        }

        Proveedor prov = mapProveedores.get(idProveedor);
        if (prov == null) {
            return "ERROR: No existe un proveedor con ID: " + idProveedor;
        }

        int nuevoId = mapProductos.size() + 1;
        Producto nuevo = new Producto(nuevoId, nombre, precio, stock, cat, prov);

        // Insertar en mapa principal
        mapProductos.put(nuevoId, nuevo);

        // Actualizar relación bidireccional Categoria → Productos
        List<Producto> prodsCat = new ArrayList<>();
        if (cat.getProductos() != null) prodsCat.addAll(cat.getProductos());
        prodsCat.add(nuevo);
        cat.setProductos(prodsCat);

        // Actualizar relación bidireccional Proveedor → Productos
        List<Producto> prodsProv = new ArrayList<>();
        if (prov.getProductos() != null) prodsProv.addAll(prov.getProductos());
        prodsProv.add(nuevo);
        prov.setProductos(prodsProv);

        // Actualizar índices agrupados
        idxProductosPorCategoria
            .computeIfAbsent(idCategoria, k -> new ArrayList<>())
            .add(nuevoId);
        idxProductosPorProveedor
            .computeIfAbsent(idProveedor, k -> new ArrayList<>())
            .add(nuevoId);

        StringBuilder sb = new StringBuilder();
        sb.append("=== PRODUCTO AGREGADO ===\n");
        sb.append("ID        : ").append(nuevoId).append("\n");
        sb.append("Nombre    : ").append(nombre).append("\n");
        sb.append("Precio    : $").append(precio).append("\n");
        sb.append("Stock     : ").append(stock).append(" unidades\n");
        sb.append("Categoría : ").append(cat.getNombre()).append("\n");
        sb.append("Proveedor : ").append(prov.getNombre()).append("\n");
        return sb.toString();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MÉTODO 5 — resumenInventario
    //   Ahora usa cat.getProductos() directamente en lugar del índice
    // ═══════════════════════════════════════════════════════════════════════
    @WebMethod(operationName = "resumenInventario")
    public String resumenInventario() {

        StringBuilder sb = new StringBuilder();
        sb.append("=== RESUMEN DE INVENTARIO ===\n\n");

        double valorTotalGeneral = 0;

        for (Map.Entry<Integer, Categoria> entry : mapCategorias.entrySet()) {
            Categoria cat = entry.getValue();

            sb.append("Categoría : ").append(cat.getNombre()).append("\n");

            List<Producto> productos = cat.getProductos();
            if (productos == null || productos.isEmpty()) {
                sb.append("  (Sin productos)\n\n");
                continue;
            }

            int    stockTotal = 0;
            double valorTotal = 0;

            // Navegar la relación bidireccional directamente
            for (Producto p : productos) {
                sb.append("  • ").append(p.getNombre())
                  .append(" | Stock: ").append(p.getStock())
                  .append(" | Precio: $").append(p.getPrecio()).append("\n");
                stockTotal += p.getStock();
                valorTotal += p.getStock() * p.getPrecio();
            }

            sb.append("  Stock total : ").append(stockTotal).append(" unidades\n");
            sb.append("  Valor total : $").append(String.format("%.2f", valorTotal)).append("\n\n");
            valorTotalGeneral += valorTotal;
        }

        sb.append("══════════════════════════════\n");
        sb.append("VALOR TOTAL INVENTARIO: $").append(String.format("%.2f", valorTotalGeneral)).append("\n");
        return sb.toString();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MÉTODO 6 — listarTodosLosMapas
    // ═══════════════════════════════════════════════════════════════════════
    @WebMethod(operationName = "listarTodosLosMapas")
    public String listarTodosLosMapas() {

        StringBuilder sb = new StringBuilder();

        sb.append("=== MAPA DE CATEGORÍAS ===\n");
        for (Map.Entry<Integer, Categoria> e : mapCategorias.entrySet()) {
            sb.append("  Clave: ").append(e.getKey())
              .append("  →  ").append(e.getValue().toString()).append("\n");
        }

        sb.append("\n=== MAPA DE PROVEEDORES ===\n");
        for (Map.Entry<Integer, Proveedor> e : mapProveedores.entrySet()) {
            sb.append("  Clave: ").append(e.getKey())
              .append("  →  ").append(e.getValue().toString()).append("\n");
        }

        sb.append("\n=== MAPA DE PRODUCTOS (LinkedHashMap) ===\n");
        for (Map.Entry<Integer, Producto> e : mapProductos.entrySet()) {
            sb.append("  Clave: ").append(e.getKey())
              .append("  →  ").append(e.getValue().toString()).append("\n");
        }

        return sb.toString();
    }
}