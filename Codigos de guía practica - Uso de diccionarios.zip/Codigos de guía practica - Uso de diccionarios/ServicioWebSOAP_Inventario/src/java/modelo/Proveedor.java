package modelo;

import java.util.List;

public class Proveedor {
    private int    idProveedor;
    private String ruc;
    private String nombre;
    private String telefono;
    private String correo;
    private String pais;
    private List<Producto> productos;

    public Proveedor() {}

    public Proveedor(int idProveedor, String ruc, String nombre,
                     String telefono, String correo, String pais) {
        this.idProveedor = idProveedor;
        this.ruc         = ruc;
        this.nombre      = nombre;
        this.telefono    = telefono;
        this.correo      = correo;
        this.pais        = pais;
    }

    public int getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }

    

    @Override
    public String toString() {
        return "Proveedor{id=" + idProveedor + ", ruc=" + ruc
                + ", nombre=" + nombre + ", pais=" + pais + "}";
    }
}