import sw.LogueoSW;
import sw.LogueoSW_Service;
public class TestLogueo {
    public static void main(String[] args) {

        LogueoSW_Service service = new LogueoSW_Service();
        LogueoSW ws = service.getLogueoSWPort();

        // ── PRUEBA 1: Login correcto ───────────────────────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 1: LOGIN CORRECTO");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.login("diego", "1234"));

        // ── PRUEBA 2: Login incorrecto ────────────────────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 2: LOGIN INCORRECTO");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.login("diego", "wrongpass"));

        // ── PRUEBA 3: Registrar nuevo usuario ─────────────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 3: REGISTRAR USUARIO");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.registrarUsuario("0107122097", "carlos2", "9999", "ADMIN"));

        // ── PRUEBA 4: Listar todos los usuarios ───────────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 4: LISTAR USUARIOS");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.listarUsuarios());

        // ── PRUEBA 5: Usuarios por rol ────────────────────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 5: USUARIOS POR ROL = USUARIO");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.usuariosPorRol("USUARIO"));

        // ── PRUEBA 6: Cambiar contraseña ──────────────────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 6: CAMBIAR CONTRASEÑA");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.cambiarPassword("maria", "abcd", "nueva123"));

        // ── PRUEBA 7: Buscar usuario por DNI ──────────────────────────────
        System.out.println("══════════════════════════════════════");
        System.out.println("PRUEBA 7: BUSCAR USUARIO POR DNI");
        System.out.println("══════════════════════════════════════");
        System.out.println(ws.buscarUsuarioPorDni("0107122095"));
    }
}