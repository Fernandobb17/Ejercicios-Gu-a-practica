package sw;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import java.util.*;
import modelo.*;

@WebService(serviceName = "LogueoSW")
public class LogueoSW {

    private static List<Persona>    personas     = new ArrayList<>();
    private static List<Usuario>    usuarios     = new ArrayList<>();
    private static List<Rol>        roles        = new ArrayList<>();
    private static List<UsuarioRol> usuarioRoles = new ArrayList<>();

    static {
        // ── Personas ──────────────────────────────────────────────────────
        Persona per1 = new Persona(1, "Diego",  "Bernal", "0107122095", "0981503586", "diego@gmail.com");
        Persona per2 = new Persona(2, "Maria",  "Lopez",  "0107122096", "0992222222", "maria@gmail.com");
        Persona per3 = new Persona(3, "Carlos", "Suarez", "0107122097", "0993333333", "carlos@gmail.com");
        personas.add(per1);
        personas.add(per2);
        personas.add(per3);

        // ── Roles ─────────────────────────────────────────────────────────
        Rol rolAdmin    = new Rol(1, "ADMIN",    true);
        Rol rolUsuario  = new Rol(2, "USUARIO",  true);
        Rol rolInvitado = new Rol(3, "INVITADO", false);
        roles.add(rolAdmin);
        roles.add(rolUsuario);
        roles.add(rolInvitado);

        // ── Usuarios ──────────────────────────────────────────────────────
        Usuario u1 = new Usuario(1, per1, "diego",  "1234");
        Usuario u2 = new Usuario(2, per2, "maria",  "abcd");
        Usuario u3 = new Usuario(3, per3, "carlos", "5678");
        Usuario u4 = new Usuario(4, per1, "diego2", "0000");   // segunda cuenta de per1
        u1.setPersona(per1);
        u2.setPersona(per2);
        u3.setPersona(per3);
        u4.setPersona(per1);
        usuarios.add(u1);
        usuarios.add(u2);
        usuarios.add(u3);
        usuarios.add(u4);

        // Relacionar personas → usuarios
        per1.setUsuarios(Arrays.asList(u1, u4));
        per2.setUsuarios(Arrays.asList(u2));
        per3.setUsuarios(Arrays.asList(u3));

        // ── UsuarioRol ────────────────────────────────────────────────────
        UsuarioRol ur1 = new UsuarioRol(u1, rolAdmin);
        UsuarioRol ur2 = new UsuarioRol(u2, rolUsuario);
        UsuarioRol ur3 = new UsuarioRol(u3, rolInvitado);
        UsuarioRol ur4 = new UsuarioRol(u4, rolUsuario);
        usuarioRoles.add(ur1);
        usuarioRoles.add(ur2);
        usuarioRoles.add(ur3);
        usuarioRoles.add(ur4);

        // Relacionar usuarios → roles
        u1.setUsuarirol(Arrays.asList(ur1));
        u2.setUsuarirol(Arrays.asList(ur2));
        u3.setUsuarirol(Arrays.asList(ur3));
        u4.setUsuarirol(Arrays.asList(ur4));
    }

    // MÉTODO 1 — login
    //   Valida credenciales y devuelve los datos del usuario + su rol
    // ═══════════════════════════════════════════════════════════════════════
    @WebMethod(operationName = "login")
    public String login(
            @WebParam(name = "user")     String user,
            @WebParam(name = "password") String password) {

        Usuario usuario = null;
        for (Usuario u : usuarios) {
            if (u.siExiste(user, password)) {
                usuario = u;
                break;
            }
        }
        if (usuario == null) {
            return "ERROR: Credenciales incorrectas";
        }

        Persona per = usuario.getPersona();
        StringBuilder sb = new StringBuilder();
        sb.append("=== LOGIN EXITOSO ===\n");
        sb.append("Usuario  : ").append(usuario.getUser()).append("\n");
        sb.append("Persona  : ").append(per.getNombre()).append(" ").append(per.getApellido()).append("\n");
        sb.append("DNI      : ").append(per.getDni()).append("\n");
        sb.append("Correo   : ").append(per.getCorreo()).append("\n\n");
        sb.append("=== ROLES ASIGNADOS ===\n");

        for (UsuarioRol ur : usuario.getUsuarirol()) {
            Rol rol = ur.getId_rol();
            sb.append(" • ").append(rol.getRol())
              .append(" — Estado: ").append(rol.isEstado() ? "Activo" : "Inactivo").append("\n");
        }
        return sb.toString();
    }

    // MÉTODO 2 — registrarUsuario
    //   Crea un nuevo usuario vinculado a una persona existente (por DNI)
    //   y le asigna un rol existente (por nombre de rol)
    // ═══════════════════════════════════════════════════════════════════════
    @WebMethod(operationName = "registrarUsuario")
    public String registrarUsuario(
            @WebParam(name = "dni")      String dni,
            @WebParam(name = "user")     String user,
            @WebParam(name = "password") String password,
            @WebParam(name = "rol")      String rolNombre) {

        // Verificar que el username no esté ya en uso
        for (Usuario u : usuarios) {
            if (u.getUser().equals(user)) {
                return "ERROR: El nombre de usuario '" + user + "' ya existe.";
            }
        }

        // Buscar persona por DNI
        Persona persona = null;
        for (Persona p : personas) {
            if (p.getDni().equals(dni)) {
                persona = p;
                break;
            }
        }
        if (persona == null) {
            return "ERROR: No se encontró ninguna persona con DNI: " + dni;
        }

        // Buscar rol por nombre
        Rol rol = null;
        for (Rol r : roles) {
            if (r.siExisteRol(rolNombre)) {
                rol = r;
                break;
            }
        }
        if (rol == null) {
            return "ERROR: No se encontró el rol '" + rolNombre + "'.";
        }

        // Crear nuevo usuario
        int nuevoId = usuarios.size() + 1;
        Usuario nuevoUsuario = new Usuario(nuevoId, persona, user, password);
        nuevoUsuario.setPersona(persona);

        // relación UsuarioRol
        UsuarioRol ur = new UsuarioRol(nuevoUsuario, rol);
        usuarioRoles.add(ur);
        nuevoUsuario.setUsuarirol(Arrays.asList(ur));
        usuarios.add(nuevoUsuario);

        // Actualizar lista de usuarios de la persona
        List<Usuario> listaActual = new ArrayList<>();
        if (persona.getUsuarios() != null) listaActual.addAll(persona.getUsuarios());
        listaActual.add(nuevoUsuario);
        persona.setUsuarios(listaActual);

        StringBuilder sb = new StringBuilder();
        sb.append("=== USUARIO REGISTRADO ===\n");
        sb.append("ID       : ").append(nuevoUsuario.getIdUsuario()).append("\n");
        sb.append("Usuario  : ").append(nuevoUsuario.getUser()).append("\n");
        sb.append("Persona  : ").append(persona.getNombre()).append(" ").append(persona.getApellido()).append("\n");
        sb.append("DNI      : ").append(persona.getDni()).append("\n");
        sb.append("Rol      : ").append(rol.getRol()).append("\n");
        return sb.toString();
    }

    // MÉTODO 3 — listarUsuarios
    //   Retorna todos los usuarios registrados con su persona y rol
    // ═══════════════════════════════════════════════════════════════════════
    @WebMethod(operationName = "listarUsuarios")
    public String listarUsuarios() {

        StringBuilder sb = new StringBuilder();
        sb.append("=== LISTADO DE USUARIOS ===\n\n");

        for (Usuario u : usuarios) {
            Persona per = u.getPersona();
            sb.append("ID       : ").append(u.getIdUsuario()).append("\n");
            sb.append("Usuario  : ").append(u.getUser()).append("\n");
            sb.append("Persona  : ").append(per.getNombre()).append(" ").append(per.getApellido()).append("\n");
            sb.append("DNI      : ").append(per.getDni()).append("\n");
            sb.append("Correo   : ").append(per.getCorreo()).append("\n");
            sb.append("Roles    :\n");
            for (UsuarioRol ur : u.getUsuarirol()) {
                Rol rol = ur.getId_rol();
                sb.append("  • ").append(rol.getRol())
                  .append(" (").append(rol.isEstado() ? "Activo" : "Inactivo").append(")\n");
            }
            sb.append("─────────────────────────\n");
        }
        return sb.toString();
    }

    // MÉTODO 4 — usuariosPorRol
    //   Lista todos los usuarios que tienen un rol específico
    // ═══════════════════════════════════════════════════════════════════════
    @WebMethod(operationName = "usuariosPorRol")
    public String usuariosPorRol(@WebParam(name = "rol") String rolNombre) {

        // Verificar que el rol exista
        boolean rolExiste = false;
        for (Rol r : roles) {
            if (r.siExisteRol(rolNombre)) { rolExiste = true; break; }
        }
        if (!rolExiste) {
            return "ERROR: No existe el rol '" + rolNombre + "'.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("=== USUARIOS CON ROL: ").append(rolNombre.toUpperCase()).append(" ===\n\n");
        boolean encontrado = false;

        for (UsuarioRol ur : usuarioRoles) {
            if (ur.getId_rol().siExisteRol(rolNombre)) {
                Usuario u   = ur.getId_usuario();
                Persona per = u.getPersona();
                sb.append("Usuario  : ").append(u.getUser()).append("\n");
                sb.append("Persona  : ").append(per.getNombre()).append(" ").append(per.getApellido()).append("\n");
                sb.append("DNI      : ").append(per.getDni()).append("\n");
                sb.append("Correo   : ").append(per.getCorreo()).append("\n");
                sb.append("─────────────────────────\n");
                encontrado = true;
            }
        }
        if (!encontrado) {
            sb.append("Ningún usuario tiene el rol '").append(rolNombre).append("'.\n");
        }
        return sb.toString();
    }

    // MÉTODO 5 — cambiarPassword
    //   Cambia la contraseña validando primero las credenciales actuales
    // ═══════════════════════════════════════════════════════════════════════
    @WebMethod(operationName = "cambiarPassword")
    public String cambiarPassword(
            @WebParam(name = "user")        String user,
            @WebParam(name = "passwordActual") String passwordActual,
            @WebParam(name = "passwordNueva")  String passwordNueva) {

        Usuario usuario = null;
        for (Usuario u : usuarios) {
            if (u.siExiste(user, passwordActual)) {
                usuario = u;
                break;
            }
        }
        if (usuario == null) {
            return "ERROR: Usuario o contraseña actual incorrectos.";
        }
        if (passwordNueva == null || passwordNueva.trim().isEmpty()) {
            return "ERROR: La nueva contraseña no puede estar vacía.";
        }

        usuario.setPassword(passwordNueva);

        StringBuilder sb = new StringBuilder();
        sb.append("=== CONTRASEÑA ACTUALIZADA ===\n");
        sb.append("Usuario  : ").append(usuario.getUser()).append("\n");
        sb.append("Persona  : ").append(usuario.getPersona().getNombre())
          .append(" ").append(usuario.getPersona().getApellido()).append("\n");
        sb.append("Estado   : Contraseña cambiada con éxito.\n");
        return sb.toString();
    }

    // MÉTODO 6 — buscarUsuarioPorDni
    //   Muestra todos los usuarios y roles asociados a un DNI
    // ═══════════════════════════════════════════════════════════════════════
    @WebMethod(operationName = "buscarUsuarioPorDni")
    public String buscarUsuarioPorDni(@WebParam(name = "dni") String dni) {

        Persona persona = null;
        for (Persona p : personas) {
            if (p.getDni().equals(dni)) {
                persona = p;
                break;
            }
        }
        if (persona == null) {
            return "ERROR: No se encontró ninguna persona con DNI: " + dni;
        }

        List<Usuario> usuariosPersona = persona.getUsuarios();
        if (usuariosPersona == null || usuariosPersona.isEmpty()) {
            return "La persona con DNI " + dni + " no tiene usuarios registrados.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("=== USUARIOS DE ").append(persona.getNombre())
          .append(" ").append(persona.getApellido())
          .append(" (DNI: ").append(dni).append(") ===\n\n");

        for (Usuario u : usuariosPersona) {
            sb.append("ID       : ").append(u.getIdUsuario()).append("\n");
            sb.append("Usuario  : ").append(u.getUser()).append("\n");
            sb.append("Roles    :\n");
            for (UsuarioRol ur : u.getUsuarirol()) {
                Rol rol = ur.getId_rol();
                sb.append("  • ").append(rol.getRol())
                  .append(" (").append(rol.isEstado() ? "Activo" : "Inactivo").append(")\n");
            }
            sb.append("─────────────────────────\n");
        }
        return sb.toString();
    }
}