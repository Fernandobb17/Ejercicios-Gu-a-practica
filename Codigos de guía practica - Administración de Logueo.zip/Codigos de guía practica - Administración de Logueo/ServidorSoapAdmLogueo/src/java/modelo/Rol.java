package modelo;

public class Rol {
    private int idRol;
    private String rol;
    private boolean estado;
    
    public Rol() {}

    public Rol(int idRol, String rol, boolean estado) {
        this.idRol = idRol;
        this.rol = rol;
        this.estado = estado;
    }

    public boolean siExisteRol(String rol) {
        return this.rol != null && this.rol.equals(rol);
    }

    public boolean estado(String rol) {
        if (this.rol != null && this.rol.equals(rol)) {
            return this.estado;
        }
        return false;
    }

    public int getIdRol() { return idRol; }
    public void setIdRol(int idRol) { this.idRol = idRol; }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    public boolean isEstado() { return estado; }
    public void setEstado(boolean estado) { this.estado = estado; }
    
    
    @Override
    public String toString() {
        return "Rol{idRol=" + idRol + ", rol=" + rol + ", estado=" + estado + "}";
    }
}