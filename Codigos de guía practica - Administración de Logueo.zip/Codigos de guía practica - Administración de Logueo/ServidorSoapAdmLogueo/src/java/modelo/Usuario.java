package modelo;

import java.util.List;

public class Usuario {
    private int idUsuario;
    private Persona idPersona;
    private String user;
    private String password;
    private Persona persona;
    
    private List<UsuarioRol> usuarirol;

    public Usuario() {}
    public Usuario(int idUsuario, Persona idPersona, String user, String password) {
        this.idUsuario = idUsuario;
        this.idPersona = idPersona;
        this.user = user;
        this.password = password;
    }
    public boolean siExiste(String user, String password) {
        return this.user != null && this.user.equals(user)
               && this.password != null && this.password.equals(password);
    }
    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }
    public Persona getIdPersona() { return idPersona; }
    public void setIdPersona(Persona idPersona) { this.idPersona = idPersona; }
    public String getUser() { return user; }
    public void setUser(String user) { this.user = user; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public Persona getPersona() { return persona; }
    public void setPersona(Persona persona) { this.persona = persona; }
    public List<UsuarioRol> getUsuarirol() {
        return usuarirol;
    }
    public void setUsuarirol(List<UsuarioRol> usuarirol) {
        this.usuarirol = usuarirol;}
    @Override
    public String toString() {
        return "Usuario{idUsuario=" + idUsuario + ", idPersona=" + idPersona + ", user=" + user + "}";
    }
}