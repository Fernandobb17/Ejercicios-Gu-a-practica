package modelo;

import java.util.List;

public class Persona {
    private int idPersona;
    private String nombre;
    private String apellido;
    private String dni;
    private String celular;
    private String correo;
    
    private List<Usuario> usuarios;

    public Persona() {}
    public Persona(int idPersona, String nombre, String apellido, String dni, String celular, String correo) {
        this.idPersona = idPersona;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.celular = celular;
        this.correo = correo;
    }
    
    public Persona buscarP(String dni) {
        if (this.dni != null && this.dni.equals(dni)) {
            return this;
        }
        return null;
    }

    public String nombreCompl(String dni) {
        if (this.dni != null && this.dni.equals(dni)) {
            return this.nombre + " " + this.apellido;
        }
        return null;
    }

    public int getIdPersona() { return idPersona; }
    public void setIdPersona(int idPersona) { this.idPersona = idPersona; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }

    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }

    public String getCelular() { return celular; }
    public void setCelular(String celular) { this.celular = celular; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }
    
    @Override
    public String toString() {
        return "Persona{idPersona=" + idPersona + ", nombre=" + nombre +
               ", apellido=" + apellido + ", dni=" + dni +
               ", celular=" + celular + ", correo=" + correo + "}";
    }
}